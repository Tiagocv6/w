const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 35 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *PIC PAY,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/5544997462158*
║
╚═〘 TIAGO NE 〙
`
}
exports.iklan = iklan
